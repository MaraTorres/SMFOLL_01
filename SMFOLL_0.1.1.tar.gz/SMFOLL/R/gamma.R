#' The gamma distribution.
#'
#' Provides density, distribution function, quantile function and random generation for the gamma distribution.
#'
#' @param param Vector with shape parameter first and scale parameter second.
#' @param x,q Vector of quantiles.
#' @param log Logical; if TRUE, probabilities p are given as log(p).
#' @param lower.tail Logical; if TRUE (default), probabilities are P[X ≤ x] otherwise, P[X > x].
#' @param cens censorship indicator.
#'
#' @name Gamma
#' @aliases dg
#' @aliases pg
#'
#' @return dg gives the density, pg gives the distribution function.
#'
#' @examples
#' pg(c(2,2),5)
#'
#' dg(c(1,1),1)
#'
dg = function(param, x, log = FALSE) {
    if (param[1] <= 0 | param[2] <= 0) {
        return(NaN)
    } else {
        shape <- param[1]
        scale <- param[2]

        u <- dgamma(x = x, shape = shape, scale = scale)

        if (log) {
            u = log(u)
        }
        return(u)
    }
}

#' @rdname Gamma
#' @export

pg = function(param, q, lower.tail = TRUE, log = FALSE) {
    if (param[1] <= 0 | param[2] <= 0) {
        return(NaN)
    } else {
        shape <- param[1]
        scale <- param[2]

        x <- pgamma(q = q, shape = shape, scale = scale)

        if (lower.tail == FALSE) {
            x = 1 - x
        }

        if (log) {
            x = log(x)
        }
        return(x)
    }
}

#' @rdname Gamma
#' @export

vgamma <- function(param, x) {
    shape <- param[1]
    scale <- param[2]

    if (any(shape < 1e-20))
        return(.Machine$double.xmax^0.5)
    if (any(scale < 1e-20))
        return(.Machine$double.xmax^0.5)

    f <- dgamma(x = x, shape = shape, scale = scale)

    lv <- log(f)

    sum(-lv)
}

#' @rdname Gamma
#' @export

sgamma <- function(param, x, cens) {
    shape <- param[1]
    scale <- param[2]

    if (any(shape < 1e-20))
        return(.Machine$double.xmax^0.5)
    if (any(scale < 1e-20))
        return(.Machine$double.xmax^0.5)

    f <- dgamma(x = x, shape = shape, scale = scale)

    S <- (1 - pgamma(q = x, shape = shape, scale = scale))

    lv <- cens * log(f) + (1 - cens) * log(S)

    sum(-lv)
}
