#' The normal distribution.
#'
#' Provides density and distribution function for the normal distribution.
#'
#' @param param Vector with shape parameter first and scale parameter second.
#' @param x,q Vector of quantiles.
#' @param log Logical; if TRUE, probabilities p are given as log(p).
#' @param lower.tail Logical; if TRUE (default), probabilities are P[X ≤ x] otherwise, P[X > x].
#' @param cens censorship indicator.
#'
#' @name Normal
#' @aliases dnormal
#' @aliases pnormal
#' @aliases qnormal
#' @aliases rnormal
#'
#' @return dnormal gives the density, pnormal gives the distribution function.
#'
#' @examples
#' pnormal(c(2,1),5)
#'
#' dnormal(c(1,3),c(2.1,1.2,0.6))
dnormal = function(param, x, log = FALSE) {
    if (param[1] <= 0 | param[2] <= 0) {
        return(NaN)
    } else {
        mu <- param[1]
        sigma <- param[2]

        u <- dnorm(x = x, mean = mu, sd = sigma)

        if (log) {
            u = log(u)
        }
        return(u)
    }
}

#' @rdname Normal
#' @export

pnormal = function(param, q, lower.tail = TRUE, log = FALSE) {
    if (param[1] <= 0 | param[2] <= 0) {
        return(NaN)
    } else {
        mu <- param[1]
        sigma <- param[2]

        x <- pnorm(q = q, mean = mu, sd = sigma)

        if (lower.tail == FALSE) {
            x = 1 - x
        }

        if (log) {
            x = log(x)
        }
        return(x)
    }
}

#' @rdname Normal
#' @export

vnorm <- function(param, x) {
    mu <- param[1]
    sigma <- param[2]

    if (any(mu < 1e-20))
        return(.Machine$double.xmax^0.5)
    if (any(sigma < 1e-20))
        return(.Machine$double.xmax^0.5)

    f <- dnorm(x = x, mean = mu, sd = sigma)

    lv <- log(f)

    sum(-lv)
}

#' @rdname Normal
#' @export

snorm <- function(param, x, cens) {
    mu <- param[1]
    sigma <- param[2]

    if (any(mu < 1e-20))
        return(.Machine$double.xmax^0.5)
    if (any(sigma < 1e-20))
        return(.Machine$double.xmax^0.5)

    f <- dnorm(x = x, mean = mu, sd = sigma)

    S <- (1 - pnorm(q = x, mean = mu, sd = sigma))

    lv <- cens * log(f) + (1 - cens) * log(S)

    sum(-lv)
}
