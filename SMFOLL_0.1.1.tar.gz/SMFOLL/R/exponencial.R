#' The exponential distribution.
#'
#' Provides density, distribution function, quantile function and random generation for the exponential distribution.
#'
#' @param param Vector with shape parameter first and scale parameter second.
#' @param x,q Vector of quantiles.
#' @param p Vector of probabilities.
#' @param n Number of observations.
#' @param log Logical; if TRUE, probabilities p are given as log(p).
#' @param lower.tail Logical; if TRUE (default), probabilities are P[X ≤ x] otherwise, P[X > x].
#' @param cens censorship indicator.
#'
#' @name Exponential
#' @aliases dexpo
#' @aliases pexpo
#' @aliases qexpo
#' @aliases rexpo
#'
#' @return dexpo gives the density, pexpo gives the distribution function, qexpo quantile function, rexpo random generation function.
#'
#' @examples
#' pexpo(2,5)
#'
#' dexpo(1,c(2.1,1.2,0.6))

dexpo <- function(param, x, log = FALSE) {
    if (param <= 0) {
        return(NaN)
    } else {

        u = param * exp(-param * x)

        if (log) {
            u = log(u)
        }
        return(u)
    }

}

#' @rdname Exponential
#' @export

pexpo <- function(param, q, lower.tail = TRUE, log = FALSE) {
    if (param <= 0) {
        return(NaN)
    } else {

        x = 1 - exp(-param * q)
        if (lower.tail == FALSE) {
            x = 1 - x
        }
        if (log) {
            x = log(x)
        }
        return(x)
    }

}

#' @rdname Exponential
#' @export

qexpo <- function(param, p, lower.tail = TRUE, log = FALSE) {
    if (param <= 0) {
        return(NaN)
    } else {

        if (lower.tail == FALSE) {
            p = 1 - p
        }
        x = -(1/param) * log(1 - p)

        if (log) {
            x = log(x)
        }
        return(x)
    }

}

#' @rdname Exponential
#' @export

rexpo <- function(param, n) {
    if (param <= 0) {
        return(NaN)
    } else {
        u = runif(n)
        x = -(1/param) * log(1 - u)
        return(x)
    }

}

#' @rdname Exponential
#' @export

vexpo <- function(param, x) {

    if (any(param < 1e-20))
        return(.Machine$double.xmax^0.5)

    f <- param * exp(-param * x)

    lv <- log(f)

    sum(-lv)
}

#' @rdname Exponential
#' @export

sexpo <- function(param, x, cens) {

    if (any(param < 1e-20))
        return(.Machine$double.xmax^0.5)

    f <- (param * exp(-param * x))

    S <- exp(-param * x)

    lv <- cens * log(f) + (1 - cens) * log(S)

    sum(-lv)
}
